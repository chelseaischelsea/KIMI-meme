import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { query, url, html, params } = body;
    
    if (!query || (!url && !html)) {
      return NextResponse.json(
        { error: 'Query and either URL or HTML are required' },
        { status: 400 }
      );
    }

    const apiKey = process.env.AGENTQL_API_KEY;
    
    if (!apiKey) {
      return NextResponse.json(
        { error: 'API key not configured' },
        { status: 500 }
      );
    }

    const response = await fetch('https://api.agentql.com/v1/query-data', {
      method: 'POST',
      headers: {
        'X-API-Key': apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        query,
        url,
        html,
        params: params || {
          wait_for: 0,
          is_scroll_to_bottom_enabled: false,
          mode: 'fast',
          is_screenshot_enabled: false
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return NextResponse.json(
        { error: 'Error from AgentQL API', details: errorData },
        { status: response.status }
      );
    }

    const data = await response.json();
    return NextResponse.json(data);
  } catch (error) {
    console.error('Error processing AgentQL request:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
