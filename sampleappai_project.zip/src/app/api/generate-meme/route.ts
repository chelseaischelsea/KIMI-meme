import { NextResponse } from 'next/server';
import OpenAI from 'openai';
import Jimp from 'jimp';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { prompt, topText, bottomText } = body;

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    // Generate image with OpenAI
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: `Create a meme image based on: ${prompt}. Make it humorous and suitable for a meme format. Do not include any text in the image.`,
      n: 1,
      size: "1024x1024",
    });

    const imageUrl = response.data[0].url;
    
    if (!imageUrl) {
      return NextResponse.json(
        { error: 'Failed to generate image' },
        { status: 500 }
      );
    }

    // If no text to overlay, just return the image URL
    if (!topText && !bottomText) {
      return NextResponse.json({ imageUrl });
    }

    // Download the image
    const imageResponse = await fetch(imageUrl);
    const imageBuffer = await imageResponse.arrayBuffer();
    
    // Process the image with Jimp to add text
    const image = await Jimp.read(Buffer.from(imageBuffer));
    const width = image.getWidth();
    const height = image.getHeight();
    
    // Load font
    const font = await Jimp.loadFont(Jimp.FONT_SANS_64_WHITE);
    
    // Add top text
    if (topText) {
      image.print(
        font,
        0,
        20,
        {
          text: topText.toUpperCase(),
          alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER,
          alignmentY: Jimp.VERTICAL_ALIGN_TOP
        },
        width,
        height
      );
    }
    
    // Add bottom text
    if (bottomText) {
      image.print(
        font,
        0,
        height - 120,
        {
          text: bottomText.toUpperCase(),
          alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER,
          alignmentY: Jimp.VERTICAL_ALIGN_BOTTOM
        },
        width,
        height
      );
    }
    
    // Convert to base64
    const base64Image = await image.getBase64Async(Jimp.MIME_JPEG);
    
    return NextResponse.json({
      imageUrl,
      memeImageBase64: base64Image
    });
  } catch (error) {
    console.error('Error generating meme:', error);
    return NextResponse.json(
      { error: 'Failed to generate meme' },
      { status: 500 }
    );
  }
}
