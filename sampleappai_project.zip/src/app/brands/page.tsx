import { Navbar } from "@/components/navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, BarChart3, Share2, Target, TrendingUp, Users } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export default function BrandsPage() {
  const features = [
    {
      icon: <Share2 className="h-6 w-6 text-primary" />,
      title: "Viral Content Creation",
      description: "Transform your brand messaging into highly shareable meme content that resonates with your target audience."
    },
    {
      icon: <Target className="h-6 w-6 text-primary" />,
      title: "Precise Targeting",
      description: "Reach specific audience segments with content tailored to their preferences and humor style."
    },
    {
      icon: <BarChart3 className="h-6 w-6 text-primary" />,
      title: "Detailed Analytics",
      description: "Track performance with comprehensive metrics on shares, engagement, and audience demographics."
    },
    {
      icon: <TrendingUp className="h-6 w-6 text-primary" />,
      title: "ROI Optimization",
      description: "Pay only for actual shares and engagement, ensuring maximum return on your marketing investment."
    },
    {
      icon: <Users className="h-6 w-6 text-primary" />,
      title: "Audience Growth",
      description: "Expand your reach organically as users share your branded memes with their networks."
    }
  ];

  const testimonials = [
    {
      quote: "Our meme campaign increased engagement by 300% compared to traditional ads!",
      author: "Sarah Johnson",
      position: "Marketing Director, TechCorp",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330"
    },
    {
      quote: "We saw a 5x increase in social shares and a 40% boost in brand recall after just one month.",
      author: "Michael Chen",
      position: "Brand Manager, FashionNow",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d"
    },
    {
      quote: "The ROI on our meme marketing strategy has outperformed all our other digital channels combined.",
      author: "Priya Patel",
      position: "CMO, SnackBrands Inc.",
      image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e"
    }
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <section className="relative overflow-hidden py-20 md:py-32 bg-gradient-to-b from-background to-muted">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Transform Your Brand Content Into Viral Memes
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Reach new audiences and drive engagement with AI-generated memes that maintain your brand voice while maximizing shareability.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg" asChild>
                    <Link href="/pricing">Get Started</Link>
                  </Button>
                  <Button size="lg" variant="outline" asChild>
                    <Link href="#how-it-works">Learn More</Link>
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative h-[350px] w-[350px] md:h-[450px] md:w-[450px]">
                  <Image
                    src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1770&q=80"
                    alt="Brand Marketing with Memes"
                    fill
                    className="object-cover rounded-lg shadow-2xl"
                    priority
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="how-it-works" className="w-full py-12 md:py-24 lg:py-32 bg-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">How It Works For Brands</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Our platform transforms your traditional advertising into shareable content that users genuinely want to distribute.
                </p>
              </div>
            </div>
            
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-3 md:gap-12 mt-16">
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="rounded-full bg-primary/10 p-3">
                  <Upload className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">1. Upload Content</h3>
                <p className="text-muted-foreground">
                  Upload your core advertising content, messaging, and brand guidelines through our intuitive dashboard.
                </p>
              </div>
              
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="rounded-full bg-primary/10 p-3">
                  <Wand className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">2. AI Transformation</h3>
                <p className="text-muted-foreground">
                  Our AI analyzes your inputs and generates multiple meme variations that maintain brand integrity while maximizing shareability.
                </p>
              </div>
              
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="rounded-full bg-primary/10 p-3">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">3. Track Results</h3>
                <p className="text-muted-foreground">
                  Access a comprehensive dashboard to track meme performance, sharing metrics, and engagement analytics in real-time.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Key Features for Brands</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Everything you need to transform your marketing strategy with viral meme content.
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, index) => (
                <Card key={index} className="h-full">
                  <CardHeader>
                    <div className="rounded-full bg-primary/10 p-3 w-fit mb-4">
                      {feature.icon}
                    </div>
                    <CardTitle>{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Success Stories</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  See how brands like yours have transformed their marketing with our AI meme generator.
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <Card key={index} className="h-full">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center text-center space-y-4">
                      <div className="relative h-16 w-16 rounded-full overflow-hidden">
                        <Image 
                          src={testimonial.image} 
                          alt={testimonial.author} 
                          fill 
                          className="object-cover"
                        />
                      </div>
                      <blockquote className="text-lg italic">"{testimonial.quote}"</blockquote>
                      <div>
                        <p className="font-semibold">{testimonial.author}</p>
                        <p className="text-sm text-muted-foreground">{testimonial.position}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Ready to Transform Your Brand Content?</h2>
                <p className="max-w-[900px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Join thousands of brands already leveraging the power of meme marketing.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" variant="secondary" asChild>
                  <Link href="/pricing">View Pricing</Link>
                </Button>
                <Button size="lg" variant="outline" className="bg-transparent" asChild>
                  <Link href="/contact">Contact Sales</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <footer className="w-full py-6 bg-background border-t">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-2">AI Meme Generator</h3>
              <p className="text-sm text-muted-foreground">
                Connecting brands with authentic social sharing through the universal language of memes.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li><Link href="/" className="text-muted-foreground hover:text-primary">Home</Link></li>
                <li><Link href="/brands" className="text-muted-foreground hover:text-primary">For Brands</Link></li>
                <li><Link href="/users" className="text-muted-foreground hover:text-primary">For Users</Link></li>
                <li><Link href="/pricing" className="text-muted-foreground hover:text-primary">Pricing</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Contact</h3>
              <ul className="space-y-2 text-sm">
                <li className="text-muted-foreground">Email: info@aimemegen.com</li>
                <li className="text-muted-foreground">Phone: +1 (555) 123-4567</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-4 border-t text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} AI Meme Generator. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

function Upload(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" x2="12" y1="3" y2="15" />
    </svg>
  );
}

function Wand(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m15 4-8 8" />
      <path d="m9 4 1 1" />
      <path d="m4 9 1 1" />
      <path d="m12 15 2 2" />
      <path d="m15 12 2 2" />
      <path d="m6 14 1 1" />
      <path d="m14 6 1 1" />
      <path d="m10 2v2" />
      <path d="m2 10h2" />
      <path d="m14 18v2" />
      <path d="m18 14h2" />
    </svg>
  );
}
