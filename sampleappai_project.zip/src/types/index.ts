export interface Meme {
  id: string;
  imageUrl: string;
  title: string;
  brandName: string;
  shares: number;
  likes: number;
  category: string;
  createdAt: string;
}

export interface Brand {
  id: string;
  name: string;
  logo: string;
  guidelines: string;
}

export interface MemeAnalytics {
  id: string;
  memeId: string;
  shares: number;
  likes: number;
  clicks: number;
  impressions: number;
  platforms: {
    name: string;
    shares: number;
  }[];
}

export interface MemeGenerationRequest {
  brandContent: string;
  brandGuidelines: string;
  targetAudience: string;
  messageGoal: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  preferences: string[];
  sharedMemes: string[];
  rewards: number;
}
