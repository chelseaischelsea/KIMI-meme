"use client";

import { useState } from "react";
import { Card, CardContent, CardFooter } from "./ui/card";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Heart, Share2, Download } from "lucide-react";
import { Meme } from "@/types";

const MOCK_MEMES: Meme[] = [
  {
    id: "1",
    imageUrl: "https://images.unsplash.com/photo-1531747118685-ca8fa6e08806",
    title: "Monday Motivation",
    brandName: "Energy Drinks Co.",
    shares: 1245,
    likes: 3456,
    category: "funny",
    createdAt: "2023-10-15",
  },
  {
    id: "2",
    imageUrl: "https://images.unsplash.com/photo-1573867639040-6dd25fa5f597",
    title: "Weekend Vibes",
    brandName: "Leisure Apparel",
    shares: 987,
    likes: 2345,
    category: "relatable",
    createdAt: "2023-10-16",
  },
  {
    id: "3",
    imageUrl: "https://images.unsplash.com/photo-1596207498818-c23411d5c2fd",
    title: "Tech Life",
    brandName: "Tech Innovations",
    shares: 654,
    likes: 1876,
    category: "tech",
    createdAt: "2023-10-17",
  },
  {
    id: "4",
    imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f",
    title: "Team Goals",
    brandName: "Office Supplies Inc.",
    shares: 432,
    likes: 1234,
    category: "work",
    createdAt: "2023-10-18",
  },
  {
    id: "5",
    imageUrl: "https://images.unsplash.com/photo-1528716321680-815a8cdb8cbe",
    title: "Friday Feeling",
    brandName: "Weekend Entertainment",
    shares: 876,
    likes: 2987,
    category: "funny",
    createdAt: "2023-10-19",
  },
  {
    id: "6",
    imageUrl: "https://images.unsplash.com/photo-1536148935331-408321065b18",
    title: "Food Cravings",
    brandName: "Gourmet Delivery",
    shares: 765,
    likes: 1543,
    category: "food",
    createdAt: "2023-10-20",
  },
];

export function MemeFeed() {
  const [activeTab, setActiveTab] = useState("all");
  const [likedMemes, setLikedMemes] = useState<string[]>([]);
  const [sharedMemes, setSharedMemes] = useState<string[]>([]);

  const handleLike = (memeId: string) => {
    setLikedMemes((prev) =>
      prev.includes(memeId) ? prev.filter((id) => id !== memeId) : [...prev, memeId]
    );
  };

  const handleShare = (memeId: string) => {
    // In a real app, this would open a share dialog
    setSharedMemes((prev) => [...prev, memeId]);
  };

  const handleDownload = (memeUrl: string) => {
    // In a real app, this would trigger a download
    window.open(memeUrl, "_blank");
  };

  const filteredMemes = activeTab === "all" 
    ? MOCK_MEMES 
    : MOCK_MEMES.filter(meme => meme.category === activeTab);

  return (
    <div className="w-full max-w-6xl mx-auto p-4">
      <h2 className="text-2xl font-bold mb-6">Trending Memes</h2>
      
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mb-8">
        <TabsList className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-7">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="funny">Funny</TabsTrigger>
          <TabsTrigger value="relatable">Relatable</TabsTrigger>
          <TabsTrigger value="tech">Tech</TabsTrigger>
          <TabsTrigger value="work">Work</TabsTrigger>
          <TabsTrigger value="food">Food</TabsTrigger>
          <TabsTrigger value="trending" className="hidden lg:block">Trending</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMemes.map((meme) => (
              <MemeCard
                key={meme.id}
                meme={meme}
                isLiked={likedMemes.includes(meme.id)}
                isShared={sharedMemes.includes(meme.id)}
                onLike={handleLike}
                onShare={handleShare}
                onDownload={handleDownload}
              />
            ))}
          </div>
        </TabsContent>
        
        {["funny", "relatable", "tech", "work", "food", "trending"].map((category) => (
          <TabsContent key={category} value={category} className="mt-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMemes.map((meme) => (
                <MemeCard
                  key={meme.id}
                  meme={meme}
                  isLiked={likedMemes.includes(meme.id)}
                  isShared={sharedMemes.includes(meme.id)}
                  onLike={handleLike}
                  onShare={handleShare}
                  onDownload={handleDownload}
                />
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

interface MemeCardProps {
  meme: Meme;
  isLiked: boolean;
  isShared: boolean;
  onLike: (id: string) => void;
  onShare: (id: string) => void;
  onDownload: (url: string) => void;
}

function MemeCard({ meme, isLiked, isShared, onLike, onShare, onDownload }: MemeCardProps) {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0 relative">
        <div className="aspect-square relative overflow-hidden">
          <img
            src={meme.imageUrl}
            alt={meme.title}
            className="w-full h-full object-cover transition-transform hover:scale-105"
          />
        </div>
        <div className="absolute top-2 right-2 bg-background/80 backdrop-blur-sm rounded-full px-2 py-1 text-xs font-medium">
          {meme.brandName}
        </div>
      </CardContent>
      <CardFooter className="flex flex-col p-4 space-y-2">
        <div className="flex justify-between items-center w-full">
          <h3 className="font-medium">{meme.title}</h3>
          <div className="text-xs text-muted-foreground">
            {new Date(meme.createdAt).toLocaleDateString()}
          </div>
        </div>
        <div className="flex justify-between items-center w-full">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              className={isLiked ? "text-red-500" : ""}
              onClick={() => onLike(meme.id)}
            >
              <Heart className="h-4 w-4 mr-1" fill={isLiked ? "currentColor" : "none"} />
              {meme.likes}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className={isShared ? "text-blue-500" : ""}
              onClick={() => onShare(meme.id)}
            >
              <Share2 className="h-4 w-4 mr-1" />
              {meme.shares}
            </Button>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onDownload(meme.imageUrl)}
          >
            <Download className="h-4 w-4 mr-1" />
            Save
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
