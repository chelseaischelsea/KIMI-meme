import { Button } from "./ui/button";
import Link from "next/link";
import Image from "next/image";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden py-20 md:py-32 bg-gradient-to-b from-background to-muted">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                Transform Brand Content Into Shareable Memes
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                Our AI platform connects brands with authentic social sharing through the universal language of memes.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button size="lg" asChild>
                <Link href="/brands">For Brands</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/users">For Users</Link>
              </Button>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative h-[350px] w-[350px] md:h-[450px] md:w-[450px]">
              <Image
                src="https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1770&q=80"
                alt="AI Meme Generator"
                fill
                className="object-cover rounded-lg shadow-2xl"
                priority
              />
              <div className="absolute -bottom-6 -right-6 h-[150px] w-[200px] md:h-[200px] md:w-[250px] bg-primary/10 backdrop-blur-sm rounded-lg flex items-center justify-center p-4 shadow-lg">
                <p className="text-sm md:text-base font-medium text-center">
                  "Our meme campaign increased engagement by 300% compared to traditional ads!"
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
