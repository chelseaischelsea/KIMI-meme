import { Check } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";

export function BenefitsSection() {
  const brandBenefits = [
    "Transform traditional ad content into organic-feeling social assets",
    "Precise tracking of where and how often your content is shared",
    "Pay-per-share model ensures you only pay for actual distribution",
    "Detailed analytics on which messaging resonates with different audience segments"
  ];

  const userBenefits = [
    "Access to premium meme content without watermarks or restrictions",
    "Content that feels authentic rather than overtly promotional",
    "Simple interface for finding and sharing the perfect meme",
    "Personalized recommendations based on your sharing history"
  ];

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Key Benefits</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Our platform offers unique advantages for both brands and users.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-16">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">For Brands</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                {brandBenefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary mt-0.5" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">For Users</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                {userBenefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary mt-0.5" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
