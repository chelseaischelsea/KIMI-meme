"use client";

import { useState } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Card, CardContent } from "./ui/card";
import { Label } from "./ui/label";
import { Upload, Image as ImageIcon, Loader2, Download, Share2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { MemeGenerationRequest } from "@/types";

export function MemeGenerator() {
  const [isLoading, setIsLoading] = useState(false);
  const [generatedMemes, setGeneratedMemes] = useState<string[]>([]);
  const [generatedMemeBase64, setGeneratedMemeBase64] = useState<string>("");
  const [formData, setFormData] = useState<MemeGenerationRequest>({
    brandContent: "",
    brandGuidelines: "",
    targetAudience: "",
    messageGoal: "",
  });
  const [memeText, setMemeText] = useState({
    topText: "",
    bottomText: ""
  });
  const { toast } = useToast();

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      "image/*": []
    },
    onDrop: (acceptedFiles) => {
      // Handle file upload logic here
      toast({
        title: "Files uploaded",
        description: `${acceptedFiles.length} files have been uploaded successfully.`,
      });
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleMemeTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setMemeText((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setGeneratedMemeBase64("");
    setGeneratedMemes([]);

    try {
      // Call our API to generate meme with OpenAI
      const response = await fetch("/api/generate-meme", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt: formData.brandContent,
          topText: memeText.topText,
          bottomText: memeText.bottomText
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to generate meme");
      }

      const data = await response.json();
      
      if (data.memeImageBase64) {
        setGeneratedMemeBase64(data.memeImageBase64);
      }
      
      if (data.imageUrl) {
        // For backward compatibility with the mock data
        setGeneratedMemes([data.imageUrl]);
      }

      toast({
        title: "Meme generated",
        description: "Your meme has been successfully generated!",
      });
    } catch (error) {
      console.error("Error generating meme:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate meme. Please try again.",
        variant: "destructive",
      });
      
      // Fallback to mock data in case of error
      const mockGeneratedMemes = [
        "https://images.unsplash.com/photo-1531747118685-ca8fa6e08806"
      ];
      setGeneratedMemes(mockGeneratedMemes);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = (imageUrl: string) => {
    // Create a temporary link to download the image
    const link = document.createElement("a");
    link.href = generatedMemeBase64 || imageUrl;
    link.download = "generated-meme.jpg";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = () => {
    if (navigator.share && (generatedMemeBase64 || generatedMemes[0])) {
      navigator.share({
        title: "Check out this meme I created!",
        text: "Generated with AI Meme Generator",
        url: generatedMemes[0] || window.location.href,
      }).catch((error) => {
        console.error("Error sharing:", error);
        toast({
          title: "Sharing failed",
          description: "Could not share the meme. Try downloading it instead.",
          variant: "destructive",
        });
      });
    } else {
      toast({
        title: "Sharing not supported",
        description: "Your browser does not support direct sharing. Try downloading the image instead.",
      });
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <h2 className="text-2xl font-bold mb-6">AI Meme Generator</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-4">
          <div>
            <Label htmlFor="brandContent">Meme Content / Prompt</Label>
            <Textarea
              id="brandContent"
              name="brandContent"
              placeholder="Describe the meme image you want to generate"
              value={formData.brandContent}
              onChange={handleInputChange}
              className="min-h-[100px]"
              required
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="topText">Top Text</Label>
              <Input
                id="topText"
                name="topText"
                placeholder="Text to display at the top of the meme"
                value={memeText.topText}
                onChange={handleMemeTextChange}
              />
            </div>
            
            <div>
              <Label htmlFor="bottomText">Bottom Text</Label>
              <Input
                id="bottomText"
                name="bottomText"
                placeholder="Text to display at the bottom of the meme"
                value={memeText.bottomText}
                onChange={handleMemeTextChange}
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="brandGuidelines">Brand Guidelines (Optional)</Label>
            <Textarea
              id="brandGuidelines"
              name="brandGuidelines"
              placeholder="Enter your brand guidelines and tone of voice"
              value={formData.brandGuidelines}
              onChange={handleInputChange}
              className="min-h-[100px]"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="targetAudience">Target Audience (Optional)</Label>
              <Input
                id="targetAudience"
                name="targetAudience"
                placeholder="Who is your target audience?"
                value={formData.targetAudience}
                onChange={handleInputChange}
              />
            </div>
            
            <div>
              <Label htmlFor="messageGoal">Message Goal (Optional)</Label>
              <Input
                id="messageGoal"
                name="messageGoal"
                placeholder="What is the goal of your message?"
                value={formData.messageGoal}
                onChange={handleInputChange}
              />
            </div>
          </div>
          
          <div>
            <Label>Upload Brand Assets (Optional)</Label>
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-6 cursor-pointer text-center transition-colors ${isDragActive ? "border-primary bg-primary/5" : "border-muted-foreground/25 hover:border-primary/50"}`}
            >
              <input {...getInputProps()} />
              <div className="flex flex-col items-center gap-2">
                <Upload className="h-8 w-8 text-muted-foreground" />
                {isDragActive ? (
                  <p>Drop the files here...</p>
                ) : (
                  <p>Drag & drop files here, or click to select files</p>
                )}
                <p className="text-xs text-muted-foreground">
                  Supports: JPG, PNG, SVG (Max 5MB)
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating Meme...
            </>
          ) : (
            "Generate Meme"
          )}
        </Button>
      </form>
      
      {(generatedMemeBase64 || generatedMemes.length > 0) && (
        <div className="mt-10">
          <h3 className="text-xl font-semibold mb-4">Generated Meme</h3>
          <div className="grid grid-cols-1 gap-4">
            <Card className="overflow-hidden">
              <CardContent className="p-0 relative aspect-square">
                <img
                  src={generatedMemeBase64 || generatedMemes[0]}
                  alt="Generated meme"
                  className="w-full h-full object-contain"
                />
                <div className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <Button size="sm" variant="secondary" onClick={() => handleDownload(generatedMemes[0])}>
                    <Download className="h-4 w-4 mr-1" /> Download
                  </Button>
                  <Button size="sm" onClick={handleShare}>
                    <Share2 className="h-4 w-4 mr-1" /> Share
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
