import { Upload, BarChart3, Share2, Download } from "lucide-react";

export function FeaturesSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">How It Works</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Our platform transforms traditional advertising into shareable content that users genuinely want to distribute.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-16">
          <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm">
            <h3 className="text-xl font-bold">For Brands</h3>
            <div className="grid grid-cols-1 gap-6 w-full">
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-primary/10 p-3">
                  <Upload className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold">Upload Content</h4>
                  <p className="text-sm text-muted-foreground">
                    Upload your core advertising content, messaging, and brand guidelines.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-primary/10 p-3">
                  <Share2 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold">Generate Memes</h4>
                  <p className="text-sm text-muted-foreground">
                    Our AI analyzes your inputs and generates multiple meme variations that maintain brand integrity.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-primary/10 p-3">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold">Track Performance</h4>
                  <p className="text-sm text-muted-foreground">
                    Access a comprehensive dashboard to track meme performance, sharing metrics, and engagement analytics.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm">
            <h3 className="text-xl font-bold">For Users</h3>
            <div className="grid grid-cols-1 gap-6 w-full">
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-primary/10 p-3">
                  <Share2 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold">Browse Memes</h4>
                  <p className="text-sm text-muted-foreground">
                    Browse a curated feed of brand-sponsored memes that match your interests and humor style.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-primary/10 p-3">
                  <Download className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold">Download & Share</h4>
                  <p className="text-sm text-muted-foreground">
                    Download high-quality meme content free of charge and share across your preferred social platforms.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-primary/10 p-3">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold">Earn Rewards</h4>
                  <p className="text-sm text-muted-foreground">
                    Earn rewards and exclusive content by sharing popular memes with your network.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
